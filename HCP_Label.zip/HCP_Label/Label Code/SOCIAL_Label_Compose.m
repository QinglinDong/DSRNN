clear;
project_root_path = '/home/share/TmpData/Qinglin/HCP_EV';
TASK = 'SOCIAL';
lenTASK = 274;
numEVENT = 4;
TR = 0.72;
cnt = 0;
isGET = 0;
src_root_path = fullfile(project_root_path);
tic;
subject_dir = dir(src_root_path);
for i = 1:5
    if( isequal(subject_dir(i).name, '.' ) ||...
        isequal(subject_dir(i).name, '..') ||...
        ~subject_dir(i).isdir)               % �������Ŀ¼������
        continue;
    end
    src_path = fullfile(src_root_path, subject_dir(i).name,'MNINonLinear/Results/tfMRI_SOCIAL_LR/EVs');
    dst_path = '/home/share/TmpData/Qinglin/HCP_Label';
    
    Label = zeros(lenTASK, numEVENT + 1);
    Label = int8(Label);
    event = cell(numEVENT, 1);
    event{1} = importdata(fullfile(src_path, 'mental.txt'));
    event{2} = importdata(fullfile(src_path, 'rnd.txt'));
    event{3} = importdata(fullfile(src_path, 'mental_resp.txt'));
    event{4} = importdata(fullfile(src_path, 'other_resp.txt'));

    for src_event = 1:2
        numSRC = size(event{src_event}, 1);
        for idx_src = 1:numSRC
            isGET = 0;
            % Mental
            numDST = size(event{3}, 1);
            for idx_dst = 1:numDST
                if event{src_event}(idx_src, :) == event{3}(idx_dst, :)
                    sttpos = ceil(event{src_event}(idx_src, 1)/TR);
                    endpos = ceil((event{src_event}(idx_src, 1) + event{src_event}(idx_src, 2))/TR);
                    Label(sttpos:endpos, 2*src_event - 1) = 1;
                    isGET = 1;
                    break;
                end
            end
            if isGET
                continue;
            end
            % Mental
            numDST = size(event{4}, 1);
            for idx_dst = 1:numDST
                if event{src_event}(idx_src, :) == event{4}(idx_dst, :)
                    sttpos = ceil(event{src_event}(idx_src, 1)/TR);
                    endpos = ceil((event{src_event}(idx_src, 1) + event{src_event}(idx_src, 2))/TR);
                    Label(sttpos:endpos, 2*src_event) = 1;
                    isGET = 1;
                    break;
                end
            end
            if isGET
                continue;
            else
                sttpos = ceil(event{src_event}(idx_src, 1)/TR);
                endpos = ceil((event{src_event}(idx_src, 1) + event{src_event}(idx_src, 2))/TR);
                Label(sttpos:endpos, 2*src_event) = 1;
            end
        end
    end
    Label(:, numEVENT + 1) = 1 - sum(Label(:, 1:numEVENT), 2);
    if max(Label(:)) > 1 || min(Label(:)) < 0 || sum(Label(:)) ~= lenTASK
        fprintf(1, 'Subject -- %s  Label Abnormal...\n', subject_dir(i).name);
    end
    filename = sprintf('%s_label.mat', TASK);
    savefile = fullfile(dst_path, filename);
    save(savefile, 'Label');
    fprintf(1, 'Subject -- %s  Complete...\n', subject_dir(i).name);
end
toc;