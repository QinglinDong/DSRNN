clear;
project_root_path = '/home/share/TmpData/Qinglin/HCP_EV';
TASK = 'EMOTION';
lenTOTAL = 187;
lenTASK = 176;
numEVENT = 2;
TR = 0.72;
src_root_path = fullfile(project_root_path);
tic;
subject_dir = dir(src_root_path);
for i = 1:100
    
    try
    
        if( isequal(subject_dir(i).name, '.' ) ||...
            isequal(subject_dir(i).name, '..') ||...
            ~subject_dir(i).isdir)               % �������Ŀ¼������
            continue;
        end
        src_path = fullfile(src_root_path, subject_dir(i).name,'MNINonLinear/Results/tfMRI_EMOTION_LR/EVs');
        dst_path = '/home/share/TmpData/Qinglin/HCP_Label';

        Label = zeros(lenTOTAL, numEVENT + 1);
        Label = int8(Label);
        event = cell(numEVENT, 1);
        event{1} = importdata(fullfile(src_path, 'fear.txt'));
        event{2} = importdata(fullfile(src_path, 'neut.txt'));

        for idx_event = 1:numEVENT
            numTRIAL = size(event{idx_event}, 1);
            for idx_trial = 1:numTRIAL
                sttpos = ceil(event{idx_event}(idx_trial, 1)/TR);
                endpos = ceil((event{idx_event}(idx_trial, 1) + event{idx_event}(idx_trial, 2))/TR);
                Label(sttpos:endpos, idx_event) = 1;
            end
        end
        Label(:, numEVENT + 1) = 1 - sum(Label(:, 1:numEVENT), 2);
        if max(Label(:)) > 1 || min(Label(:)) < 0 || sum(Label(:)) ~= lenTOTAL
            fprintf(1, 'Subject -- %s  Label Abnormal...\n', subject_dir(i).name);
        end
        Label = Label(1:lenTASK, :);
        filename = sprintf('%s_label.mat', TASK);
        savefile = fullfile(dst_path, filename);
        save(savefile, 'Label');
        fprintf(1, 'Subject -- %s  Complete...\n', subject_dir(i).name);
    catch
        fprintf(1, 'Subject -- %s  Label Abnormal...\n', subject_dir(i).name);
    end
end
toc;